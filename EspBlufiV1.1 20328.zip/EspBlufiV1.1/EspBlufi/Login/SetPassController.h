//
//  SetPassController.h
//  DJRegisterViewDemo
//
//  Created by zhi weijian.
//  Copyright (c) 2016年 zhi weijian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetPassController : UIViewController

@end
