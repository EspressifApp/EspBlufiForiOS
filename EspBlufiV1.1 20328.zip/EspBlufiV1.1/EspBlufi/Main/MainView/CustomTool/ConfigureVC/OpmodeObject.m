//
//  OpmodeObject.m
//  EspBlufi
//
//  Copyright 2017-2018 Espressif Systems (Shanghai) PTE LTD.
//  This code is licensed under Espressif MIT License, found in LICENSE file.
//

#import "OpmodeObject.h"

@implementation OpmodeObject

@end
