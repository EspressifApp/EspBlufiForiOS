//
//  NSLayoutConstraint+MASDebugAdditions.h
//  Masonry
//
//  Copyright 2017-2018 Espressif Systems (Shanghai) PTE LTD.
//  This code is licensed under Espressif MIT License, found in LICENSE file.
//

#import "MASUtilities.h"

/**
 *	makes debug and log output of NSLayoutConstraints more readable
 */
@interface NSLayoutConstraint (MASDebugAdditions)

@end
