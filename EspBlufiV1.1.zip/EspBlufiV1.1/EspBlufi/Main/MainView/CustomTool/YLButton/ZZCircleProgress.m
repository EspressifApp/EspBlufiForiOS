//
//  ZZCircleProgress.m
//  ZZCircleProgressDemo
//
//  Copyright 2017-2018 Espressif Systems (Shanghai) PTE LTD.
//  This code is licensed under Espressif MIT License, found in LICENSE file.

#import "ZZCircleProgress.h"
#import "NSTimer+timerBlock.h"

//角度转换为弧度
#define CircleDegreeToRadian(d) ((d)*M_PI)/180.0
//255进制颜色转换
#define CircleRGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
//宽高定义
#define CircleSelfWidth self.frame.size.width
#define CircleSelfHeight self.frame.size.height

#define  MarginOffset 10
#define DEGREE_TO_RADIAN(degree) (((degree) * M_PI) / 180.0f)
#define CompassToCartesian(rad) ((rad) - M_PI / 2 )

@interface ZZCircleProgress()

@property(nonatomic,strong)UILabel *BGValueLabel;
@property(nonatomic,strong)UILabel *UnitLabel;
@property(nonatomic,strong)UIImageView *imageview;
@property(nonatomic,strong)NSTimer *RotateTimer;


@property(nonatomic,strong)UIImageView *SensorView;

@end

@implementation ZZCircleProgress
{
    CGFloat fakeProgress;
    NSTimer *timer;//定时器用作动画
    CGRect Sensorimagerect;
}

- (instancetype)init {
    if (self = [super init]) {
        [self initialization];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initialization];
    }
    return self;
}

//初始化
- (instancetype)initWithFrame:(CGRect)frame
                pathBackColor:(UIColor *)pathBackColor
                pathFillColor:(UIColor *)pathFillColor
                   startAngle:(CGFloat)startAngle
                  strokeWidth:(CGFloat)strokeWidth {
    if (self = [super initWithFrame:frame]) {
        [self initialization];
        if (pathBackColor) {
            _pathBackColor = pathBackColor;
        }
        if (pathFillColor) {
            _pathFillColor = pathFillColor;
        }
        _startAngle = CircleDegreeToRadian(startAngle);
        _strokeWidth = strokeWidth;
    }
    return self;
}

//初始化数据
- (void)initialization {
    self.backgroundColor = [UIColor clearColor];
    _pathBackColor = CircleRGB(204, 204, 204);
    _pathFillColor = CircleRGB(219, 184, 102);
    _strokeWidth = 10;//线宽默认为10
    _startAngle = -CircleDegreeToRadian(90);//圆起点位置
    _reduceValue = CircleDegreeToRadian(0);//整个圆缺少的角度
    _animationModel = CircleIncreaseByProgress;//根据进度来
    _showPoint = YES;//小圆点
    _showProgressText = YES;//文字
    _forceRefresh = NO;//一直刷新动画
    
    fakeProgress = 0.0;//用来逐渐增加直到等于progress的值
    
    [self drawHandleWithdegree:135];
    [self drawHandleWithdegree:62.5];
    [self drawHandleWithdegree:0];
    [self drawHandleWithdegree:-62.5];
    [self drawHandleWithdegree:-135];
    
    //获取图片资源
    NSBundle *mainBundle = [NSBundle bundleForClass:[self class]];
    NSBundle *resourcesBundle = [NSBundle bundleWithPath:[mainBundle pathForResource:@"ZZCircleProgress" ofType:@"bundle"]];
    _pointImage = [UIImage imageNamed:@"circle_point1" inBundle:resourcesBundle compatibleWithTraitCollection:nil];
    
    CGFloat labelW=CircleSelfWidth*0.8;
    CGFloat labelH=40.0;
    UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake((CircleSelfWidth- labelW)/2.0, (CircleSelfHeight- labelH)/2.0, labelW, labelH)];
    //textLabel.backgroundColor=[UIColor redColor];
    textLabel.text=NSLocalizedString(@"waitdata", nil);
    textLabel.textColor=[UIColor whiteColor];
    textLabel.font=[UIFont systemFontOfSize:50];
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.adjustsFontSizeToFitWidth=YES;
    [self addSubview:textLabel];
    self.BGValueLabel=textLabel;
    
    CGFloat unitunitlabelW=100;
    CGRect r2 = CGRectMake((CircleSelfWidth-unitunitlabelW)/2, CGRectGetMaxY(textLabel.frame)+10,unitunitlabelW, 20);
    UILabel *unitlabel=[[UILabel alloc]initWithFrame:r2];
    unitlabel.backgroundColor=[UIColor clearColor];
    unitlabel.textColor=[UIColor whiteColor];
    unitlabel.textAlignment=NSTextAlignmentCenter;
    //unitlabel.text=_unittext;
    unitlabel.text=@"mg/dL";
    [self addSubview:unitlabel];
    self.UnitLabel=unitlabel;
    
    //电池图标
    CGFloat imageW=25;
    CGFloat imageH=15;
    CGRect imagerect = CGRectMake((CircleSelfWidth-imageW)/2, (CGRectGetMinY(textLabel.frame)-_strokeWidth-imageH)/2+_strokeWidth+10, imageW, imageH);
    UIImageView *imageview=[[UIImageView alloc]initWithFrame:imagerect];
    [imageview setImage:[UIImage imageNamed:@"battery100"]];
    [self addSubview:imageview];
    self.imageview=imageview;
    
    UIImageView *SensorImage=[[UIImageView alloc]init];
    SensorImage.backgroundColor=[UIColor clearColor];
    SensorImage.image=_pointImage;
    [self addSubview:SensorImage];
    _SensorView=SensorImage;
    
}

#pragma Set
- (void)setStartAngle:(CGFloat)startAngle {
    if (_startAngle != CircleDegreeToRadian(startAngle)) {
        _startAngle = CircleDegreeToRadian(startAngle);
        [self setNeedsDisplay];
    }
}

- (void)setReduceValue:(CGFloat)reduceValue {
    if (_reduceValue != CircleDegreeToRadian(reduceValue)) {
        if (reduceValue>=360) {
            return;
        }
        _reduceValue = CircleDegreeToRadian(reduceValue);
        [self setNeedsDisplay];
    }
}

- (void)setStrokeWidth:(CGFloat)strokeWidth {
    if (_strokeWidth != strokeWidth) {
        _strokeWidth = strokeWidth;
        [self setNeedsDisplay];
    }
}

- (void)setPathBackColor:(UIColor *)pathBackColor {
    if (_pathBackColor != pathBackColor) {
        _pathBackColor = pathBackColor;
        [self setNeedsDisplay];
    }
}

- (void)setPathFillColor:(UIColor *)pathFillColor {
    if (_pathFillColor != pathFillColor) {
        _pathFillColor = pathFillColor;
        [self setNeedsDisplay];
    }
}

- (void)setShowPoint:(BOOL)showPoint {
    if (_showPoint != showPoint) {
        _showPoint = showPoint;
        [self setNeedsDisplay];
    }
}

-(void)setShowProgressText:(BOOL)showProgressText {
    if (_showProgressText != showProgressText) {
        _showProgressText = showProgressText;
        [self setNeedsDisplay];
    }
}


//画背景线、填充线、小圆点、文字
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    //获取图形上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    //设置中心点 半径 起点及终点
    CGFloat maxWidth = self.frame.size.width<self.frame.size.height?self.frame.size.width-MarginOffset:self.frame.size.height-MarginOffset;
    CGPoint center = CGPointMake(maxWidth/2.0+MarginOffset/2, maxWidth/2.0+MarginOffset/2);
    CGFloat radius = maxWidth/2.0-_strokeWidth/2.0;//留出一像素，防止与边界相切的地方被切平
    CGFloat endA = _startAngle + (CircleDegreeToRadian(360) - _reduceValue);//圆终点位置
    CGFloat valueEndA = _startAngle + (CircleDegreeToRadian(360)-_reduceValue)*fakeProgress;  //数值终点位置
    
    //背景线
    UIBezierPath *basePath = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:_startAngle endAngle:endA clockwise:YES];
    //线条宽度
    CGContextSetLineWidth(ctx, _strokeWidth);
    //设置线条顶端
    CGContextSetLineCap(ctx, kCGLineCapRound);
    //线条颜色
    [_pathBackColor setStroke];
    //把路径添加到上下文
    CGContextAddPath(ctx, basePath.CGPath);
    //渲染背景线
    CGContextStrokePath(ctx);
    
    //路径线
    UIBezierPath *valuePath = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:_startAngle endAngle:valueEndA clockwise:YES];
    //设置线条顶端
    CGContextSetLineCap(ctx, kCGLineCapRound);
    //线条颜色
    [_pathFillColor setStroke];
    //把路径添加到上下文
    CGContextAddPath(ctx, valuePath.CGPath);
    //渲染数值线
    CGContextStrokePath(ctx);
    
    //画小圆点
    if (_showPoint) {
        CGFloat R=_strokeWidth;
        CGRect rest=CGRectMake(center.x+radius*cosf(valueEndA)-R, center.y+radius*sinf(valueEndA)-R, 2*R, 2*R);
       // CGContextDrawImage(ctx,rest, _pointImage.CGImage);
        _SensorView.frame=rest;
        _SensorView.image=_pointImage;
       
    }
    if (_showProgressText) {
        
    }
}
- (void)drawHandleWithdegree:(float)degree {
    
    CGPoint handleCenter = [self pointOnCircleAtRadian:DEGREE_TO_RADIAN(degree)];
    float LS_HANDLE_RADIUS=_strokeWidth/4.f;
    CALayer *outerCircleLayer = [CALayer layer];
    outerCircleLayer.bounds = CGRectMake(0, 0, LS_HANDLE_RADIUS * 2, LS_HANDLE_RADIUS * 2);
    outerCircleLayer.cornerRadius = LS_HANDLE_RADIUS;
    outerCircleLayer.position = handleCenter;
    
    outerCircleLayer.backgroundColor = [UIColor blackColor].CGColor;
    outerCircleLayer.opacity=0.1;
    //outerCircleLayer.zPosition=-1;
    [self.layer addSublayer:outerCircleLayer];
    
}

- (CGPoint)pointOnCircleAtRadian:(CGFloat)radian {
    CGPoint centerPoint=CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2);
    CGFloat radius=(self.bounds.size.width-MarginOffset-_strokeWidth)/2.f;
    CGFloat cartesianRadian = CompassToCartesian(radian);
    CGVector offset = CGVectorMake(radius * cos(cartesianRadian), radius * sin(cartesianRadian));
    return CGPointMake(centerPoint.x + offset.dx, centerPoint.y + offset.dy);
}

//设置进度
- (void)setProgress:(CGFloat)progress {
    
    if ((_progress == progress && !_forceRefresh) || progress>1.0 || progress<0.0) {
        return;
    }
    
    fakeProgress = _increaseFromLast==YES?_progress:0.0;
    BOOL isReverse = progress<fakeProgress?YES:NO;
    //赋真实值
    _progress = progress;
    
    //先暂停计时器
    if (timer) {
        [timer invalidate];
        timer = nil;
    }
    //如果为0或没有动画则直接刷新
    if (_progress == 0.0 || _notAnimated) {
        fakeProgress = _progress;
        [self setNeedsDisplay];
        return;
    }
    
    //设置每次增加的数值
    CGFloat sameTimeIncreaseValue = _increaseFromLast==YES?fabs(fakeProgress-_progress):_progress;
    CGFloat defaultIncreaseValue = isReverse==YES?-0.01:0.01;
    
    __weak typeof(self) weakSelf = self;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:0.005 block:^{
        __strong typeof(weakSelf)strongSelf = weakSelf;
        
        //反方向动画
        if (isReverse) {
            if (fakeProgress <= _progress || fakeProgress <= 0.0f) {
                [strongSelf dealWithLast];
                return;
            } else {
                //进度条动画
                [strongSelf setNeedsDisplay];
            }
        } else {
            //正方向动画
            if (fakeProgress >= _progress || fakeProgress >= 1.0f) {
                [strongSelf dealWithLast];
                return;
            } else {
                //进度条动画
                [strongSelf setNeedsDisplay];
            }
        }
        //数值增加或减少
        if (_animationModel == CircleIncreaseSameTime) {
            fakeProgress += defaultIncreaseValue*sameTimeIncreaseValue;//不同进度动画时间基本相同
        } else {
            fakeProgress += defaultIncreaseValue;//进度越大动画时间越长。
        }
        
    } repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    
}

//最后一次动画所做的处理
- (void)dealWithLast {
    //最后一次赋准确值
    fakeProgress = _progress;
    [self setNeedsDisplay];
    if (timer) {
        [timer invalidate];
        timer = nil;
    }
}

-(void)RefreshBGvalueTitle:(NSString *)str
{
    //_valuetext=str;
    _BGValueLabel.text=str;
}
-(void)RefreshUnitTitle:(NSString *)str
{
    //_unittext=str;
    _UnitLabel.text=str;
}
-(void)RefreshbatteryImage:(NSString *)str
{
    //_imagename=str;
    _imageview.image=[UIImage imageNamed:str];
}
-(void)RefreshRefreshBGvalueTitleColor:(UIColor *)color
{
    _BGValueLabel.textColor=color;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    //_SensorView.transform=CGAffineTransformMakeRotation(M_PI/2);
    
}
-(void)StartRotate
{
    [self.RotateTimer invalidate];
    self.RotateTimer=[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(SensorRotate) userInfo:nil repeats:YES];
    
}
-(void)SensorRotate
{
    _SensorView.transform=CGAffineTransformRotate(_SensorView.transform, M_PI/8);
}
-(void)StopRotate
{
    [self.RotateTimer invalidate];
}

@end
